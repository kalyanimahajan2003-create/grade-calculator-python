def calculate_average(grades):
    return sum(grades) / len(grades)


def assign_letter_grade(avg):
    if avg >= 90:
        return 'A'
    elif avg >= 80:
        return 'B'
    elif avg >= 70:
        return 'C'
    elif avg >= 60:
        return 'D'
    else:
        return 'F'


def validate_grade(score):
    try:
        score = float(score)
        if 0 <= score <= 100:
            return score
        else:
            raise ValueError("Grade must be between 0 and 100")
    except:
        raise ValueError("Invalid grade input")


# Bonus function
def find_class_extremes(students):
    averages = {}

    for name, grades in students.items():
        avg = calculate_average(grades)
        averages[name] = avg

    highest = max(averages.values())
    lowest = min(averages.values())

    top_students = [name for name, avg in averages.items() if avg == highest]
    low_students = [name for name, avg in averages.items() if avg == lowest]

    return top_students, highest, low_students, lowest