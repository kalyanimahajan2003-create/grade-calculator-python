from utils import calculate_average, assign_letter_grade, validate_grade, find_class_extremes

students = {}

while True:
    name = input("Enter student name (or press Enter to finish): ")

    if name == "":
        break

    grades = []

    for i in range(3):
        while True:
            try:
                score = input(f"Enter grade {i+1} for {name}: ")
                valid_score = validate_grade(score)
                grades.append(valid_score)
                break
            except ValueError as e:
                print("Error:", e)

    students[name] = grades


print("\n----- Student Report -----")
print("{:<15} {:<10} {:<10}".format("Name", "Average", "Grade"))

for name, grades in students.items():
    avg = calculate_average(grades)
    letter = assign_letter_grade(avg)

    print("{:<15} {:<10.2f} {:<10}".format(name, avg, letter))


# Bonus section
if students:
    top_students, highest, low_students, lowest = find_class_extremes(students)

    print("\nHighest Average:", highest)
    print("Top Student(s):", ", ".join(top_students))

    print("\nLowest Average:", lowest)
    print("Student(s):", ", ".join(low_students))